function Booking() {
  return (
    <>
      <h1>Booking page</h1>
    </>
  );
}
export default Booking;
