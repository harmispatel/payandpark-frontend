import React, { Component } from "react";


// reset form fields when modal is form, closed

export default class Error extends Component {

  render() {
    return (
      <div>
        page not found
      </div>
    );
  }
};
