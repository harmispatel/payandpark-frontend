import { Layout } from "antd";
const { Footer } = Layout;

export default function footer() {
    return (
        <Footer style={{ textAlign: "center" }}>Beyond X Labs GmbH.</Footer>
    );
}
