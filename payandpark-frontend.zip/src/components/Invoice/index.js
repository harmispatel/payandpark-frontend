function PaymentAndInvoice() {
  return (
    <>
      <h1>Payment And Invoice</h1>
    </>
  );
}
export default PaymentAndInvoice;
